module.exports = {
  secret: "supersecretalltheway",
  database: "mongodb://localhost:27017/chat-app"
}
